﻿create table OrderLine(
Phone_Num			char(10),
StatusID       int,
TotalPrice          money,
Foreign Key(Phone_Num) references Customer(Phone_Num),
Foreign Key(StatusID) references Status(StatusID)
)