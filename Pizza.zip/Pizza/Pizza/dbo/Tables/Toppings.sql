﻿create table Toppings(
ToppingID       int           not null    Primary Key    identity(10,2),
ToppingName     varchar(50)   not null,
ToppingPrice    money         not null
)