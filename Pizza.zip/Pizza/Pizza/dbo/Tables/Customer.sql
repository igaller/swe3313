﻿create table Customer(
Phone_Num			char(10)		not null Primary Key,
FName				varchar(50)     not null,
LName				varchar(50)     not null,
Street				varchar(50),
City				varchar(50),
State				char(2),
Zipcode				char(5)
)