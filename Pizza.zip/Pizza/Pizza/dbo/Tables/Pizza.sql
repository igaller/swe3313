﻿create table Pizza(
PizzaID         int           not null   Primary Key   identity(1,1),
Name            varchar(50)   not null,
Description     varchar(Max)  not null,
Price           money	      not null
)