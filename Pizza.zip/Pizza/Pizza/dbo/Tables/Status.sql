﻿create table Status(
StatusID			int     not null Primary Key identity(100,10),
StatusName				varchar(50)
)